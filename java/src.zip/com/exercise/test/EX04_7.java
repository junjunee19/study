package com.exercise.test;

public class EX04_7 {

	public static void main(String[] args) {
		int value =(int) (Math.random()*6+1);//math.random();
		System.out.println("value:"+value);

	}

}
