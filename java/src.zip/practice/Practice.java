package practice;

public class Practice {

	public static void main(String[] args) {
		String star="*";
		
		for (int row1 = 10; row1 <1; row1--) {
			for (int col1 = 1; col1 < row1; col1++) {
				System.out.print(star);
			}
			System.out.println();
		}
		
		

	}

}
